A demo for a device CRUD based on this [blog](http://technokayiti.blogspot.com/2013/04/angular-tutorial-learning-journey.html)
